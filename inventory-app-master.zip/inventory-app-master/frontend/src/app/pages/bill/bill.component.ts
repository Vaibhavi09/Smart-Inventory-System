import { Component } from '@angular/core';

@Component({
  selector: 'app-bill',
  imports: [],
  templateUrl: './bill.component.html',
  styleUrl: './bill.component.css'
})
export class BillComponent {

}
